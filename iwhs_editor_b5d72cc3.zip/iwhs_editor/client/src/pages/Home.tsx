import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Download } from "lucide-react";

interface LetterData {
  recipientName: string;
  recipientStreet: string;
  recipientCity: string;
  recipientState: string;
  recipientZip: string;
  date: string;
  position: string;
  effectiveDate: string;
  salary: string;
  grades: string;
  acceptanceDeadline: string;
  orientationDate: string;
  principalName: string;
  principalDate: string;
}

const initialData: LetterData = {
  recipientName: "Mr. David Mueller",
  recipientStreet: "Walnut Street",
  recipientCity: "Carthage",
  recipientState: "IL",
  recipientZip: "62321",
  date: "May 16, 2024",
  position: "Mathematics Teacher",
  effectiveDate: "May 16, 2024",
  salary: "$59,1796",
  grades: "9–11",
  acceptanceDeadline: "May 27, 2024",
  orientationDate: "August 01, 2024",
  principalName: "Amanda Congdon",
  principalDate: "May 17, 2024",
};

export default function Home() {
  const [data, setData] = useState<LetterData>(initialData);

  const handleChange = (field: keyof LetterData, value: string) => {
    setData((prev) => ({ ...prev, [field]: value }));
  };

  const downloadPDF = () => {
    const content = generateLetterHTML();
    const printWindow = window.open("", "", "width=800,height=600");
    if (printWindow) {
      printWindow.document.write(content);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const generateLetterHTML = () => {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Job Offer Letter</title>
        <style>
          body {
            font-family: 'Times New Roman', serif;
            line-height: 1.6;
            color: #1a1a1a;
            margin: 40px;
            max-width: 8.5in;
          }
          .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #333;
            padding-bottom: 20px;
          }
          .header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: bold;
          }
          .logo {
            width: 50px;
            height: 50px;
            margin-bottom: 10px;
          }
          .school-info {
            margin-bottom: 30px;
            font-size: 14px;
          }
          .school-info h2 {
            margin: 0 0 10px 0;
            font-size: 16px;
          }
          .school-info p {
            margin: 5px 0;
          }
          .letter-date {
            margin-bottom: 30px;
          }
          .letter-date p {
            margin: 0;
          }
          .recipient {
            margin-bottom: 30px;
          }
          .recipient p {
            margin: 5px 0;
          }
          .subject {
            margin-bottom: 20px;
            font-weight: bold;
          }
          .body {
            text-align: justify;
            margin-bottom: 20px;
          }
          .body p {
            margin: 15px 0;
          }
          .signature {
            margin-top: 40px;
          }
          .signature p {
            margin: 5px 0;
          }
          strong {
            font-weight: bold;
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Illini West High School</h1>
        </div>
        
        <div class="school-info">
          <h2>Illini West High School</h2>
          <p>600 Miller Street, Carthage, IL 62321</p>
          <p>Phone: +1 217-357-2136 | Email: info@illiniwest.org</p>
          <p>Website: http://www.illiniwest.org/</p>
        </div>

        <div class="letter-date">
          <p><strong>Date:</strong> ${data.date}</p>
        </div>

        <div class="recipient">
          <p><strong>To:</strong></p>
          <p>${data.recipientName}</p>
          <p>${data.recipientStreet},</p>
          <p>${data.recipientCity}, ${data.recipientState} ${data.recipientZip}</p>
        </div>

        <div class="subject">
          <p><strong>Subject:</strong> Appointment as High School ${data.position}</p>
        </div>

        <div class="body">
          <p>Dear ${data.recipientName.split(" ").pop()},</p>
          
          <p>We are delighted to offer you the position of <strong>${data.position}</strong> at <strong>Illini West High School</strong>, effective <strong>${data.effectiveDate}</strong>. The role includes an annual salary of <strong>${data.salary}</strong> along with benefits such as health insurance, retirement contributions, and professional development opportunities.</p>
          
          <p>Your responsibilities will include teaching <strong>grades ${data.grades}</strong>, preparing engaging lesson plans, and actively participating in school events and activities. Please confirm your acceptance by returning the attached acceptance form no later than <strong>${data.acceptanceDeadline}</strong>. Orientation will be held on <strong>${data.orientationDate}</strong>.</p>
          
          <p>We look forward to welcoming you to the <strong>Illini West High School</strong> team and appreciate the expertise and enthusiasm you will bring to our students.</p>
        </div>

        <div class="signature">
          <p>Sincerely,</p>
          <p style="margin-top: 40px;">${data.principalName}</p>
          <p><strong>Principal</strong></p>
          <p>Illini West High School</p>
          <p><strong>Date:</strong> ${data.principalDate}</p>
        </div>
      </body>
      </html>
    `;
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="flex flex-col lg:flex-row gap-8 p-6 lg:p-8 max-w-7xl mx-auto">
        {/* Editor Section */}
        <div className="flex-1 space-y-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2" style={{ fontFamily: "Playfair Display, serif" }}>
              Letter Editor
            </h1>
            <p className="text-muted-foreground">Edit the job offer letter fields below</p>
          </div>

          <div className="space-y-6">
            {/* Recipient Information */}
            <div className="border-b border-border pb-6">
              <h2 className="text-lg font-semibold text-foreground mb-4" style={{ fontFamily: "Playfair Display, serif" }}>
                Recipient Information
              </h2>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="recipientName" className="text-sm font-medium">
                    Full Name
                  </Label>
                  <Input
                    id="recipientName"
                    value={data.recipientName}
                    onChange={(e) => handleChange("recipientName", e.target.value)}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="recipientStreet" className="text-sm font-medium">
                    Street Address
                  </Label>
                  <Input
                    id="recipientStreet"
                    value={data.recipientStreet}
                    onChange={(e) => handleChange("recipientStreet", e.target.value)}
                    className="mt-1"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="recipientCity" className="text-sm font-medium">
                      City
                    </Label>
                    <Input
                      id="recipientCity"
                      value={data.recipientCity}
                      onChange={(e) => handleChange("recipientCity", e.target.value)}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="recipientState" className="text-sm font-medium">
                      State
                    </Label>
                    <Input
                      id="recipientState"
                      value={data.recipientState}
                      onChange={(e) => handleChange("recipientState", e.target.value)}
                      className="mt-1"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="recipientZip" className="text-sm font-medium">
                    ZIP Code
                  </Label>
                  <Input
                    id="recipientZip"
                    value={data.recipientZip}
                    onChange={(e) => handleChange("recipientZip", e.target.value)}
                    className="mt-1"
                  />
                </div>
              </div>
            </div>

            {/* Letter Details */}
            <div className="border-b border-border pb-6">
              <h2 className="text-lg font-semibold text-foreground mb-4" style={{ fontFamily: "Playfair Display, serif" }}>
                Letter Details
              </h2>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="date" className="text-sm font-medium">
                    Letter Date
                  </Label>
                  <Input
                    id="date"
                    value={data.date}
                    onChange={(e) => handleChange("date", e.target.value)}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="position" className="text-sm font-medium">
                    Position Title
                  </Label>
                  <Input
                    id="position"
                    value={data.position}
                    onChange={(e) => handleChange("position", e.target.value)}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="effectiveDate" className="text-sm font-medium">
                    Effective Date
                  </Label>
                  <Input
                    id="effectiveDate"
                    value={data.effectiveDate}
                    onChange={(e) => handleChange("effectiveDate", e.target.value)}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="salary" className="text-sm font-medium">
                    Annual Salary
                  </Label>
                  <Input
                    id="salary"
                    value={data.salary}
                    onChange={(e) => handleChange("salary", e.target.value)}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="grades" className="text-sm font-medium">
                    Grades to Teach
                  </Label>
                  <Input
                    id="grades"
                    value={data.grades}
                    onChange={(e) => handleChange("grades", e.target.value)}
                    className="mt-1"
                  />
                </div>
              </div>
            </div>

            {/* Important Dates */}
            <div className="border-b border-border pb-6">
              <h2 className="text-lg font-semibold text-foreground mb-4" style={{ fontFamily: "Playfair Display, serif" }}>
                Important Dates
              </h2>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="acceptanceDeadline" className="text-sm font-medium">
                    Acceptance Deadline
                  </Label>
                  <Input
                    id="acceptanceDeadline"
                    value={data.acceptanceDeadline}
                    onChange={(e) => handleChange("acceptanceDeadline", e.target.value)}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="orientationDate" className="text-sm font-medium">
                    Orientation Date
                  </Label>
                  <Input
                    id="orientationDate"
                    value={data.orientationDate}
                    onChange={(e) => handleChange("orientationDate", e.target.value)}
                    className="mt-1"
                  />
                </div>
              </div>
            </div>

            {/* Principal Information */}
            <div className="pb-6">
              <h2 className="text-lg font-semibold text-foreground mb-4" style={{ fontFamily: "Playfair Display, serif" }}>
                Principal Information
              </h2>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="principalName" className="text-sm font-medium">
                    Principal Name
                  </Label>
                  <Input
                    id="principalName"
                    value={data.principalName}
                    onChange={(e) => handleChange("principalName", e.target.value)}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="principalDate" className="text-sm font-medium">
                    Principal Signature Date
                  </Label>
                  <Input
                    id="principalDate"
                    value={data.principalDate}
                    onChange={(e) => handleChange("principalDate", e.target.value)}
                    className="mt-1"
                  />
                </div>
              </div>
            </div>

            {/* Action Button */}
            <Button
              onClick={downloadPDF}
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90 py-2 px-4 rounded-md font-medium flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              Print / Download Letter
            </Button>
          </div>
        </div>

        {/* Preview Section */}
        <div className="flex-1 lg:sticky lg:top-8 lg:h-fit">
          <div className="border border-border rounded-lg bg-card p-8 shadow-sm">
            <h2 className="text-lg font-semibold text-foreground mb-6" style={{ fontFamily: "Playfair Display, serif" }}>
              Preview
            </h2>
            <div className="bg-white text-foreground text-sm leading-relaxed space-y-4 font-serif max-h-96 overflow-y-auto">
              <div className="text-center border-b border-border pb-4">
                <p className="font-bold text-base">Illini West High School</p>
              </div>

              <div className="text-xs">
                <p className="font-bold mb-1">Illini West High School</p>
                <p>600 Miller Street, Carthage, IL 62321</p>
                <p>Phone: +1 217-357-2136 | Email: info@illiniwest.org</p>
                <p>Website: http://www.illiniwest.org/</p>
              </div>

              <div>
                <p>
                  <strong>Date:</strong> {data.date}
                </p>
              </div>

              <div>
                <p>
                  <strong>To:</strong>
                </p>
                <p>{data.recipientName}</p>
                <p>{data.recipientStreet},</p>
                <p>
                  {data.recipientCity}, {data.recipientState} {data.recipientZip}
                </p>
              </div>

              <div>
                <p>
                  <strong>Subject:</strong> Appointment as High School {data.position}
                </p>
              </div>

              <div>
                <p>Dear {data.recipientName.split(" ").pop()},</p>

                <p>
                  We are delighted to offer you the position of <strong>{data.position}</strong> at{" "}
                  <strong>Illini West High School</strong>, effective <strong>{data.effectiveDate}</strong>. The role includes
                  an annual salary of <strong>{data.salary}</strong> along with benefits such as health insurance, retirement
                  contributions, and professional development opportunities.
                </p>

                <p>
                  Your responsibilities will include teaching <strong>grades {data.grades}</strong>, preparing engaging lesson
                  plans, and actively participating in school events and activities. Please confirm your acceptance by returning
                  the attached acceptance form no later than <strong>{data.acceptanceDeadline}</strong>. Orientation will be held
                  on <strong>{data.orientationDate}</strong>.
                </p>

                <p>
                  We look forward to welcoming you to the <strong>Illini West High School</strong> team and appreciate the
                  expertise and enthusiasm you will bring to our students.
                </p>
              </div>

              <div>
                <p>Sincerely,</p>
                <p className="mt-8">{data.principalName}</p>
                <p>
                  <strong>Principal</strong>
                </p>
                <p>Illini West High School</p>
                <p>
                  <strong>Date:</strong> {data.principalDate}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
